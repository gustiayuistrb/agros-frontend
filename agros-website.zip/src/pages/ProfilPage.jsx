import React from 'react';
import Profil from '../components/Profil';

function ProfilPage() {
  return (
    <div>
      <Profil />
    </div>
  );
}

export default ProfilPage;
