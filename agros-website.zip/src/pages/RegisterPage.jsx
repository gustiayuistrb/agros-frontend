import React from 'react';
import Register from '../components/Register';

function RegisterPage() {
  return (
    <div>
      <Register />
    </div>
  );
}

export default RegisterPage;
